import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';
import { EpOfferToUPCMapping } from '../ep-offer-upc/model/EpOfferToUPCMapping';


@Injectable({ providedIn: 'root' })
export class DescisionTableService {

    constructor(
        private http: HttpClient,
        private router: Router) { }

    
    updateEpOfferToUPCDT(epOfferUPCForm): Observable<EpOfferToUPCMapping> { 
        const uri  = 'http://localhost:8080/service/jrules/create-entry';
        return this.http.post<EpOfferToUPCMapping>(uri,epOfferUPCForm);
    }
}