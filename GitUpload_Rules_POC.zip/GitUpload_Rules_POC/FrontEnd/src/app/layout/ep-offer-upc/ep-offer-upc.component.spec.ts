import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EpOfferUpcComponent } from './ep-offer-upc.component';

describe('EpOfferUpcComponent', () => {
  let component: EpOfferUpcComponent;
  let fixture: ComponentFixture<EpOfferUpcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EpOfferUpcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EpOfferUpcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
