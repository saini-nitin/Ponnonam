export class EpOfferToUPCMapping {
    userid:string;
    password:string;
    skuCode:string;
    upcCode:string;
    offerId:string;
}