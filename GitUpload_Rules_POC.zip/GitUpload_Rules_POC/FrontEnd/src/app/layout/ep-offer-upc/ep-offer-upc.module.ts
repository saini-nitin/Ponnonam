import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbCarouselModule, NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { MaterialModule } from '../../material/material.module';
import { PageHeaderModule } from '../../shared/index';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { FlashMessagesModule ,FlashMessagesService} from 'angular2-flash-messages';
import { BlockUIModule } from 'ng-block-ui';
import { EpOfferUpcComponent } from './ep-offer-upc.component';
import { EpOfferUpcRoutingModule } from './ep-offer-upc-routing.module';


@NgModule({
  imports: [
    CommonModule,
    NgbCarouselModule.forRoot(),
    NgbAlertModule.forRoot(),
    EpOfferUpcRoutingModule,
    MaterialModule,
    PageHeaderModule,
    FormsModule,
    ReactiveFormsModule,
    FlashMessagesModule.forRoot(),
    BlockUIModule.forRoot({
      message: 'Loading...'            
    })        
],
  providers:[FlashMessagesService],
  declarations: [EpOfferUpcComponent]
})
export class EpOfferUpcModule { }
