import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EpOfferUpcComponent } from './ep-offer-upc.component';


const routes: Routes = [
    {
        path: '', component: EpOfferUpcComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class EpOfferUpcRoutingModule {
}
