import { Component, OnInit } from '@angular/core';
import { BlockUI,NgBlockUI } from 'ng-block-ui';
import { Subject } from 'rxjs/Subject';
import {FormControl,Validators,FormGroup} from '@angular/forms';
import { routerTransition } from '../../router.animations';
import { DescisionTableService } from '../services/decision-table.serviec';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FlashMessagesService } from 'angular2-flash-messages/module/flash-messages.service';


@Component({
  selector: 'app-ep-offer-upc',
  templateUrl: './ep-offer-upc.component.html',
  styleUrls: ['./ep-offer-upc.component.scss'],
  animations: [routerTransition()]  
})
export class EpOfferUpcComponent implements OnInit {

  @BlockUI() blockUI : NgBlockUI; 
  componentDestroyed: Subject<boolean> = new Subject();  
  private sub: any;

  constructor(
    private http: HttpClient, 
    private router:Router,
    private decisionTableService: DescisionTableService,
    private _flashMessagesService: FlashMessagesService    
  ) {}

  ngOnInit() {
  }


  formValidationMessages = {
    'skuCode': [
      { type: 'required', message: 'Product SKU Code is required' }
    ],
    'upcCode': [
      { type: 'required', message: 'UPC Code is required' }
    ],
    'offerId': [
      { type: 'required', message: 'Offer ID is required' }
    ]
  }

  epOfferUPCForm = new FormGroup({
    skuCode: new FormControl('', Validators.compose([
    Validators.required
    ])),
    upcCode: new FormControl('', Validators.compose([
      Validators.required
    ])),
    offerId: new FormControl('', Validators.compose([
        Validators.required
    ]))
  })

  updateEPOfferToUPCDT(epOfferUPCForm) : void{
    epOfferUPCForm.userid = localStorage.getItem('userid');
    epOfferUPCForm.passord = localStorage.getItem('password');
    console.log('epOfferUPCForm------->',epOfferUPCForm);
    this.blockUI.start();     
    this.sub = this.decisionTableService.updateEpOfferToUPCDT(epOfferUPCForm).subscribe(
      data => {
        this.blockUI.stop();        
        console.log('data------->',data)
      },
      err =>{
        console.log('binding err object',err);
        window.scroll(0,0);        
        this.blockUI.stop();      
      }
    );
  }

  ngOnDestroy() {
    this.componentDestroyed.next(true);
    this.componentDestroyed.complete();
    if(this.sub!==undefined){
      this.sub.unsubscribe();
    }
  }

  errorFunction(err) :void{
    this._flashMessagesService.show(err, { cssClass: 'alert-danger', timeout: 10000,showCloseBtn: true }); 
  }
}
