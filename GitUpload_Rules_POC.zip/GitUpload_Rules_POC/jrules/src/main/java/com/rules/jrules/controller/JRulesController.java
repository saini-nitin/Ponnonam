package com.rules.jrules.controller;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.rules.jrules.model.EpOfferToUPCMapping;


@CrossOrigin(origins = "*")
@RestController
@EnableAutoConfiguration
@RequestMapping("/service/jrules")
public class JRulesController {

	@RequestMapping(value ="/create-entry",method = RequestMethod.POST, produces= MediaType.APPLICATION_JSON_VALUE)
	public EpOfferToUPCMapping createEPToOfferUPCDTEntry(@RequestBody EpOfferToUPCMapping decisionTableData) {
		EpOfferToUPCMapping ep = new EpOfferToUPCMapping();
		ep.setOfferId("test offer id");
		ep.setSkuCode("test sku code");
		ep.setUpcCode("test upc code");
		return ep;
	}
}
